<?php
session_start();
include("connection.php");

$mobile = $_POST['mobile'];
$password = $_POST['password'];
$role = $_POST['role'];

// Check if the hardcoded admin credentials are provided
if ($mobile === '123456789' && $password === 'admin') {
    // Hardcoded user session for admin
    $_SESSION['userdata'] = [
        'mobile' => $mobile,
        'role' => 3 // Assuming role 3 is Admin
    ];
    
    // Redirect to the admin dashboard
    echo '<script>window.location = "../routes/admindashboard.php";</script>';
} else {
    // Check the database for other users
    $check = mysqli_query($connect, "SELECT * FROM user WHERE mobile = '$mobile' AND password = '$password' AND role = '$role'");
    
    if (mysqli_num_rows($check) > 0) {
        $userdata = mysqli_fetch_array($check);
        $groups = mysqli_query($connect, "SELECT * FROM user WHERE role = 2");
        $groupsdata = mysqli_fetch_all($groups, MYSQLI_ASSOC);
        
        $_SESSION['userdata'] = $userdata;
        $_SESSION['groupsdata'] = $groupsdata;

        // Redirect to the user dashboard
        echo '<script>window.location = "../routes/dashboard.php";</script>';
    } else {
        echo '<script>alert("Invalid credentials or User not found!"); window.location = "../index.html";</script>';
    }
}
?>
