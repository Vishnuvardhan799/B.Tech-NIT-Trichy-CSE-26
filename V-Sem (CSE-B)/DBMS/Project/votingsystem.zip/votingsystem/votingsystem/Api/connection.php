<?php
    // Connection string format: "host=hostname dbname=database user=username password=password"
    $connect = pg_connect("host=localhost dbname=votingsystem user=root password=yourpassword");

    if (!$connect) {
        die("Connection failed: " . pg_last_error());
    }
?>
