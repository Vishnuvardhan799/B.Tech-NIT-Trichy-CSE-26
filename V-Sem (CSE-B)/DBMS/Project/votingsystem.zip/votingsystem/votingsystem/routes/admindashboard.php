<?php
session_start();
if (!isset($_SESSION['userdata'])) {
    header("location: ../index.html");
    exit();
}

$userdata = $_SESSION['userdata'];
$groupsdata = $_SESSION['groupsdata'];

// Find the group with the highest votes
$highestVotesGroup = null;
foreach ($groupsdata as $group) {
    if ($highestVotesGroup === null || $group['votes'] > $highestVotesGroup['votes']) {
        $highestVotesGroup = $group;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Online Voting System - Dashboard</title>
    <link rel="stylesheet" href="../css/style_index.css">
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        
        .mainsection {
            max-width: 800px;
            margin: auto;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            padding: 20px;
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .headersection {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-bottom: 20px;
        }

        .backbtn, .logoutbtn, #votebtn {
            padding: 10px 15px;
            background-color: #3498db;
            border-radius: 8px;
            color: white;
            font-size: 15px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .backbtn:hover, .logoutbtn:hover, #votebtn:hover {
            background-color: #2980b9;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .Group {
            display: flex;
            flex-direction: column;
            gap: 20px;
            margin-top: 20px;
        }

        .group-card {
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
            position: relative;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .group-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.2);
        }

        .highlight {
            border: 2px solid #27ae60;
            background-color: #dff0d8; /* Light green background */
        }

        .group-image {
            float: right;
            margin-left: 15px;
            border-radius: 50%; /* Make image circular */
            width: 100px;
            height: 100px;
        }

        .group-details {
            overflow: hidden; /* Clear floats */
        }
    </style>
</head>
<body>
    <div class="mainsection">
        <div class="headersection">
            <a href="../index.html"><button class="backbtn">Back</button></a>
            <a href="../routes/logout.php"><button class="logoutbtn">Logout</button></a>
        </div>
        <h1>Vote Count</h1>
        <div class="Group">
            <?php foreach ($groupsdata as $group): ?>
                <div class="group-card <?php echo ($group === $highestVotesGroup) ? 'highlight' : ''; ?>">
                    <div class="group-details">
                        <img src="../uploads/<?php echo htmlspecialchars($group['photo']); ?>" class="group-image" alt="Group Photo">
                        <b>Group Name:</b> <?php echo htmlspecialchars($group['name']); ?><br><br>
                        <b>Votes:</b> <?php echo $group['votes']; ?><br><br>

                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
