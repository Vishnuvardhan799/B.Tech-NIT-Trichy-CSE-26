<?php
session_start();
if (!isset($_SESSION['userdata'])) {
    header("location: ../index.html");
    exit();
}

$userdata = $_SESSION['userdata'];
$groupsdata = $_SESSION['groupsdata'];
$status = $_SESSION['userdata']['status'] == 0 ? '<b style="color:red">Not Voted</b>' : '<b style="color:green">Voted</b>';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Online Voting System - Dashboard</title>
    <link rel="stylesheet" href="../css/style_index.css">
    <style>
        body {
            background-color: #f4f4f4;
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
        }

        .mainsection {
            padding: 20px;
        }

        .headersection {
            width: 100%;
            text-align: center;
            margin-bottom: 20px;
        }

        .headersection h1 {
            color: #343a40;
            font-size: 2.5em;
            margin: 0;
        }

        .headersection button {
            padding: 10px 15px;
            background-color: #3498db;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 15px;
            cursor: pointer;
            margin: 0 5px;
            transition: background-color 0.3s;
        }

        .headersection button:hover {
            background-color: #2980b9;
        }

        .profile {
            background-color: white;
            width: 30%;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            margin-right: 20px;
        }

        .group {
            background-color: white;
            width: 60%;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .profile img, .group img {
            border-radius: 50%;
            transition: transform 0.3s;
        }

        .profile img:hover, .group img:hover {
            transform: scale(1.1);
        }

        .profile b, .group b {
            display: block;
            margin-top: 10px;
        }

        .group div {
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }

        #votebtn {
            padding: 10px 15px;
            background-color: #3498db;
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .container{
            display:flex;

        }
        #votebtn:hover {
            background-color: #2980b9;
        }
        .btns{
            width: 100%;
            display: flex;
            justify-content:center;

        }
        .backbtn, .logoutbtn{
            margin: 20px 20px;
            padding: 10px 15px;
            background-color: #3498db;
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
            transition: background-color 0.3s;
        }

    </style>
</head>
<body>
    <div class="mainsection">
    
        <div class="headersection">
            <h1>Online Voting System</h1>
            
        </div>
        <div class="container">
        <div class="profile">
            <center>
                <img src="../uploads/<?php echo htmlspecialchars($userdata['photo']); ?>" height="100" width="100"><br><br>
                <b>Name:</b> <?php echo htmlspecialchars($userdata['name']); ?>
                <b>Mobile:</b> <?php echo htmlspecialchars($userdata['mobile']); ?>
                <b>Address:</b> <?php echo htmlspecialchars($userdata['address']); ?>
                <b>Status:</b> <?php echo $status; ?>
            </center>
        </div>
        <div class="group">
            <?php foreach ($groupsdata as $group): ?>
                <div>
                    <img src="../uploads/<?php echo htmlspecialchars($group['photo']); ?>" height="100" width="100" style="float:right;">
                    <b>Group Name:</b> <?php echo htmlspecialchars($group['name']); ?>
                    <form action="../Api/vote.php" method="POST">
                        <input type="hidden" name="gvotes" value="<?php echo $group['votes']; ?>">
                        <input type="hidden" name="gid" value="<?php echo $group['id']; ?>">
                        <input type="submit" name="votebtn" value="Vote" id="votebtn">
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
        
    </div>
    <div class="btns">    
        <a href="../index.html"><button class="backbtn">Back</button></a>
        <a href="../routes/logout.php"><button class="logoutbtn">Logout</button></a>
    </div>
    </div>
</body>
</html>
